﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace RadarDataReciever
{
    public partial class FormRadarStubReciever : Form
    {
        string dataRecv;
        byte[] bufferRecv = new byte[1024];
        IPAddress ipAdressServer = IPAddress.Parse("192.168.1.6");
        IPAddress ipAdressClient = IPAddress.Parse("192.168.1.6");
        int portNoServer = Convert.ToInt32(45001);
        int portNoClient = Convert.ToInt32(45002);
        IPEndPoint iPEndPointServer;
        IPEndPoint iPEndPointClient;
        EndPoint remote;
        Thread t1;
        //creating Socket udp type
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

        public FormRadarStubReciever()
        {
            InitializeComponent();
            t1 = new Thread(Connect1);

            iPEndPointServer = new IPEndPoint(ipAdressServer, portNoServer);
            iPEndPointClient = new IPEndPoint(ipAdressClient, portNoClient);
            //typecasting IPEndPoint to EndPoint
            remote = (EndPoint)iPEndPointServer;
            socket.Bind(iPEndPointClient);

            t1.Start();//starting connect function thread
        }

        private void Connect1()
        {
            try
            {
                while (true)
                {
                    //recieve data from buffer and reading it 
                    /////////////////////////////////////////
                    socket.ReceiveFrom(bufferRecv, ref remote);//storing data coming from remote to bufferRecv
                    dataRecv = Encoding.ASCII.GetString(bufferRecv);//converting byte data to string
                    string[] s = dataRecv.Split('$');
                    //to avoid threading exception
                    if (InvokeRequired)
                    {
                        BeginInvoke(new Action(() =>
                        {
                            labelCurrentLat.Text = "Current Lat\n" + s[0] + " deg";
                            labelCurrentLong.Text = "Current Long\n" + s[1] + " deg";
                            labelCurrentHeading.Text = "Current Heading\n" + s[2] + " deg";
                            labelCurrentGroundSpeed.Text = "Current Ground Speed\n" + s[3] + " " +
                            "" +
                            "kmph";
                        }));
                    }
                    else
                    {
                        labelCurrentLat.Text = "Current Lat\n" + s[0] +" deg";
                        labelCurrentLong.Text = "Current Lat\n" + s[1] + " deg";
                        labelCurrentHeading.Text = "Current Heading\n" + s[2] + " deg";
                        labelCurrentGroundSpeed.Text = "Current Ground Speed\n" + s[3] + " kmph";
                    }
                    for (int i = 0; i < 1024; i++)
                        bufferRecv[i] = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection not established\n" + ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //aborting connect function
            t1.Abort();
            //closing socket
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }
    }
}

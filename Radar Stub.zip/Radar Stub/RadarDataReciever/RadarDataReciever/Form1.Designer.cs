﻿namespace RadarDataReciever
{
    partial class FormRadarStubReciever
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCurrentLat = new System.Windows.Forms.Label();
            this.labelCurrentLong = new System.Windows.Forms.Label();
            this.labelCurrentGroundSpeed = new System.Windows.Forms.Label();
            this.labelCurrentHeading = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelCurrentLat
            // 
            this.labelCurrentLat.AutoSize = true;
            this.labelCurrentLat.Location = new System.Drawing.Point(12, 27);
            this.labelCurrentLat.Name = "labelCurrentLat";
            this.labelCurrentLat.Size = new System.Drawing.Size(59, 13);
            this.labelCurrentLat.TabIndex = 0;
            this.labelCurrentLat.Text = "Current Lat";
            // 
            // labelCurrentLong
            // 
            this.labelCurrentLong.AutoSize = true;
            this.labelCurrentLong.Location = new System.Drawing.Point(13, 82);
            this.labelCurrentLong.Name = "labelCurrentLong";
            this.labelCurrentLong.Size = new System.Drawing.Size(68, 13);
            this.labelCurrentLong.TabIndex = 1;
            this.labelCurrentLong.Text = "Current Long";
            // 
            // labelCurrentGroundSpeed
            // 
            this.labelCurrentGroundSpeed.AutoSize = true;
            this.labelCurrentGroundSpeed.Location = new System.Drawing.Point(13, 195);
            this.labelCurrentGroundSpeed.Name = "labelCurrentGroundSpeed";
            this.labelCurrentGroundSpeed.Size = new System.Drawing.Size(113, 13);
            this.labelCurrentGroundSpeed.TabIndex = 2;
            this.labelCurrentGroundSpeed.Text = "Current Ground Speed";
            // 
            // labelCurrentHeading
            // 
            this.labelCurrentHeading.AutoSize = true;
            this.labelCurrentHeading.Location = new System.Drawing.Point(13, 141);
            this.labelCurrentHeading.Name = "labelCurrentHeading";
            this.labelCurrentHeading.Size = new System.Drawing.Size(84, 13);
            this.labelCurrentHeading.TabIndex = 3;
            this.labelCurrentHeading.Text = "Current Heading";
            // 
            // FormRadarStubReciever
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(240, 267);
            this.Controls.Add(this.labelCurrentHeading);
            this.Controls.Add(this.labelCurrentGroundSpeed);
            this.Controls.Add(this.labelCurrentLong);
            this.Controls.Add(this.labelCurrentLat);
            this.Name = "FormRadarStubReciever";
            this.Text = "Radar Stub Reciever";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCurrentLat;
        private System.Windows.Forms.Label labelCurrentLong;
        private System.Windows.Forms.Label labelCurrentGroundSpeed;
        private System.Windows.Forms.Label labelCurrentHeading;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace RadarStub
{
    public partial class FormRadarStub : Form
    {
        string dataSend;
        byte[] bufferSend = new byte[1024];
        IPAddress ipAdressServer = IPAddress.Parse("192.168.1.6");
        IPAddress ipAdressClient = IPAddress.Parse("192.168.1.6");
        int portNoServer = Convert.ToInt32(45001);
        int portNoClient = Convert.ToInt32(45002);
        IPEndPoint iPEndPointServer;
        IPEndPoint iPEndPointClient;
        EndPoint remote;
        Thread t;
        //creating a new socket 
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        ////////////////////////////////////////////////////////////////////////////////////
        double initialLat; //= 45.000000;
        double initialLong; //= 45.000000;
        double groundSpeed; //= 555; //kmph, aircraft heading towards north
        double currentLatitude;
        double currentLongitude;
        double heading;
        double headingRadian;
        int i = 0;
        bool flag = true;
        ///////////////////////////////////////////////////////////////////////////////////


        public FormRadarStub()
        {
            InitializeComponent();
            t = new Thread(connect);

            iPEndPointServer = new IPEndPoint(ipAdressServer, portNoServer);
            iPEndPointClient = new IPEndPoint(ipAdressClient, portNoClient);
            // typecasting ipendpoint to endpoint
            remote = (EndPoint)iPEndPointClient;
            socket.Bind(iPEndPointServer);

            //t.Start();//starting connect function thread
        }

        private void connect()
        {
            flag = false;
            try
            {
                DateTime time1 = DateTime.Now;
                while (i < 10)
                {
                    DateTime time2 = DateTime.Now;
                    TimeSpan ts = time2 - time1;
                    double tsSec = ts.Seconds;
                    double latIncrement = Math.Cos(headingRadian)*(Convert.ToDouble(groundSpeed/111) / Convert.ToDouble(3600)) * Convert.ToDouble(tsSec);
                    double longIncrement = Math.Sin(headingRadian) * (Convert.ToDouble(groundSpeed / 111) / Convert.ToDouble(3600)) * Convert.ToDouble(tsSec);
                    if (currentLatitude == -90 || currentLatitude == 90)
                    {
                        double temp = heading;
                        heading = -temp;
                    }
                    else
                    {
                        currentLatitude = initialLat + latIncrement;
                    }
                    if (currentLongitude == 180 || currentLongitude == -180)
                    {
                        double temp = currentLongitude;
                        currentLongitude = -temp;
                    }

                        
                    
                    currentLongitude = initialLong + longIncrement;
                    if (InvokeRequired)
                    {
                        BeginInvoke(new Action(() =>
                        {
                            labelLat.Text = "Current Lat " + Convert.ToString(currentLatitude) + " deg";
                            labelLong.Text = "Current Long " + Convert.ToString(currentLongitude) + " deg";
                        }));
                    }
                    else
                    {
                        labelLat.Text = "Current Lat " + Convert.ToString(currentLatitude);
                        labelLong.Text = "Current Long " + Convert.ToString(currentLongitude);
                    }
                    dataSend = Convert.ToString(currentLatitude)+"$"+Convert.ToString(currentLongitude)+"$"+Convert.ToString(heading)+"$"+Convert.ToString(groundSpeed);
                    bufferSend = Encoding.ASCII.GetBytes(dataSend);//converting string to byte datatype
                    socket.SendTo(bufferSend, remote);//send buffersend to remote
                    Thread.Sleep(1000);                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection not established\n"+ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //aborting connect function
            t.Abort();
            //closing socket
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
          
            try
            {
                initialLat = Convert.ToDouble(textBoxLat.Text);
                initialLong = Convert.ToDouble(textBoxLong.Text);
                groundSpeed = Convert.ToDouble(textBoxGroundSpeed.Text);
                heading = Convert.ToDouble(textBoxHeading.Text);
                headingRadian = heading * Math.PI / 180;
            }
            catch
            {
                MessageBox.Show("Please enter correct values");
            }
            if(flag == true)
            t.Start();
        }
    }
}

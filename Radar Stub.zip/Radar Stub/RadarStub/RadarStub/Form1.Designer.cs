﻿namespace RadarStub
{
    partial class FormRadarStub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSend = new System.Windows.Forms.Button();
            this.textBoxLat = new System.Windows.Forms.TextBox();
            this.textBoxLong = new System.Windows.Forms.TextBox();
            this.textBoxHeading = new System.Windows.Forms.TextBox();
            this.textBoxGroundSpeed = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelLat = new System.Windows.Forms.Label();
            this.labelLong = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonSend
            // 
            this.buttonSend.Location = new System.Drawing.Point(129, 154);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 23);
            this.buttonSend.TabIndex = 0;
            this.buttonSend.Text = "Send";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // textBoxLat
            // 
            this.textBoxLat.Location = new System.Drawing.Point(140, 36);
            this.textBoxLat.Name = "textBoxLat";
            this.textBoxLat.Size = new System.Drawing.Size(100, 20);
            this.textBoxLat.TabIndex = 1;
            this.textBoxLat.Text = "45";
            // 
            // textBoxLong
            // 
            this.textBoxLong.Location = new System.Drawing.Point(140, 62);
            this.textBoxLong.Name = "textBoxLong";
            this.textBoxLong.Size = new System.Drawing.Size(100, 20);
            this.textBoxLong.TabIndex = 2;
            this.textBoxLong.Text = "45";
            // 
            // textBoxHeading
            // 
            this.textBoxHeading.Location = new System.Drawing.Point(140, 88);
            this.textBoxHeading.Name = "textBoxHeading";
            this.textBoxHeading.Size = new System.Drawing.Size(100, 20);
            this.textBoxHeading.TabIndex = 3;
            this.textBoxHeading.Text = "0";
            // 
            // textBoxGroundSpeed
            // 
            this.textBoxGroundSpeed.Location = new System.Drawing.Point(140, 114);
            this.textBoxGroundSpeed.Name = "textBoxGroundSpeed";
            this.textBoxGroundSpeed.Size = new System.Drawing.Size(100, 20);
            this.textBoxGroundSpeed.TabIndex = 4;
            this.textBoxGroundSpeed.Text = "555";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Lat (degree)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Long (degree)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Heading (degree)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ground Speed (kmph)";
            // 
            // labelLat
            // 
            this.labelLat.AutoSize = true;
            this.labelLat.Location = new System.Drawing.Point(23, 203);
            this.labelLat.Name = "labelLat";
            this.labelLat.Size = new System.Drawing.Size(55, 13);
            this.labelLat.TabIndex = 9;
            this.labelLat.Text = "Current lat";
            // 
            // labelLong
            // 
            this.labelLong.AutoSize = true;
            this.labelLong.Location = new System.Drawing.Point(23, 230);
            this.labelLong.Name = "labelLong";
            this.labelLong.Size = new System.Drawing.Size(68, 13);
            this.labelLong.TabIndex = 10;
            this.labelLong.Text = "Current Long";
            // 
            // FormRadarStub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 287);
            this.Controls.Add(this.labelLong);
            this.Controls.Add(this.labelLat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxGroundSpeed);
            this.Controls.Add(this.textBoxHeading);
            this.Controls.Add(this.textBoxLong);
            this.Controls.Add(this.textBoxLat);
            this.Controls.Add(this.buttonSend);
            this.Name = "FormRadarStub";
            this.Text = "Radar Stub";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.TextBox textBoxLat;
        private System.Windows.Forms.TextBox textBoxLong;
        private System.Windows.Forms.TextBox textBoxHeading;
        private System.Windows.Forms.TextBox textBoxGroundSpeed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelLat;
        private System.Windows.Forms.Label labelLong;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ShapesIPCclient
{
    public partial class Form1 : Form
    {
        Color color;
        int size = 10;
        int width = 1;
        int shape = 0;
        int styleType;
        int x = 10;
        int y = 10;
        int?[] X = new int?[10];
        int?[] Y = new int?[10];
        static int flag = 0;
        float[] style = new float[2];
        Pen pen;
        ////////////////////////////////////////////////////////
        string dataRecv;
        string dataRecvtemp;
        string temp;
        byte[] bufferSend = new byte[1024];
        byte[] bufferRecv = new byte[1024];
        IPAddress ipAdressServer = IPAddress.Parse("192.168.1.6");
        IPAddress ipAdressClient = IPAddress.Parse("192.168.1.6");
        int portNoServer = Convert.ToInt32(45001);
        int portNoClient = Convert.ToInt32(45002);
        IPEndPoint iPEndPointServer;
        IPEndPoint iPEndPointClient;
        EndPoint remote;
        Thread t1;
        //creating Socket udp type
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

        public Form1()
        {
            InitializeComponent();
            t1 = new Thread(Connect1);

            iPEndPointServer = new IPEndPoint(ipAdressServer, portNoServer);
            iPEndPointClient = new IPEndPoint(ipAdressClient, portNoClient);
            //typecasting IPEndPoint to EndPoint
            remote = (EndPoint)iPEndPointServer;
            socket.Bind(iPEndPointClient);

            t1.Start();//starting connect function thread
        }

        private void Connect1()
        {
            try
            {
                while (true)
                {
                    //recieve data from buffer and reading it 
                    /////////////////////////////////////////
                    socket.ReceiveFrom(bufferRecv, ref remote);//storing data coming from remote to bufferRecv
                    dataRecvtemp = Encoding.ASCII.GetString(bufferRecv);//converting byte data to string
                    
                        dataRecv = dataRecvtemp;
                        //MessageBox.Show("Client\n" + dataRecv);
                        string[] s = dataRecv.Split(',');
                        styleType = Convert.ToInt32(s[1]);
                        width = Convert.ToInt32(s[2]);

                    if (styleType == 0)//style1
                        {
                            style[0] = 0.1F;
                            style[1] = 0.1F;
                        }
                        if (styleType == 1)//style2
                        {
                            style[0] = 0.25F;
                            style[1] = 0.25F;
                        }
                        if (styleType == 2)//style3
                        {
                            style[0] = 0.50F;
                            style[1] = 0.25F;
                        }
                        using (pen = new Pen(Color.Black, width))
                        {
                            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Custom;
                            pen.DashPattern = style;
                            Graphics graphics = panel1.CreateGraphics();
                            
                            
                            if (s[0] == "polygon")
                            {

                            }
                            else if (s[0] == "square")
                            {
                                size = Convert.ToInt32(s[3]);
                                x = Convert.ToInt32(s[4]);
                                y = Convert.ToInt32(s[5]);
                                
                                graphics.DrawRectangle(pen, x, y, size, size);
                            }
                            else if (s[0] == "circle")
                            {
                                size = Convert.ToInt32(s[3]);
                                x = Convert.ToInt32(s[4]);
                                y = Convert.ToInt32(s[5]);
                                
                                graphics.DrawEllipse(pen, x, y, size, size);
                            }
                            
                        }
                        Thread.Sleep(1000);
                    }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection not established\n" + ex.Message);               
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //aborting connect function
            t1.Abort();
            //closing socket
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonClearPanel_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
        }
    }
}

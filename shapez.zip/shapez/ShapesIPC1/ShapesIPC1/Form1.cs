﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ShapesIPC1
{
    public partial class Form1 : Form
    {
        Color color;
        int size = 10;
        int width = 1;
        int shape = 0;
        int x = 10;
        int y = 10;
        int?[] X = new int? [10];
        int?[] Y = new int? [10];
        static int flag = 0;
        float[] style = new float[2];
        Pen pen;

        ///////////////////////////////////////////////////
        string size_,width_,style_,shape_,flag_,finalString;
        string x_ = "10";
        string y_ = "10";
        string[] X_ = new string[10];
        string[] Y_ = new string[10];
        byte[] bufferSend = new byte[1024];
        byte[] bufferRecv = new byte[1024];
        IPAddress ipAdressServer = IPAddress.Parse("192.168.1.6");
        IPAddress ipAdressClient = IPAddress.Parse("192.168.1.6");
        int portNoServer = Convert.ToInt32(45001);
        int portNoClient = Convert.ToInt32(45002);
        IPEndPoint iPEndPointServer;
        IPEndPoint iPEndPointClient;
        EndPoint remote;
        Thread t;
        //creating a new socket 
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        /////////////////////////////////////////////////////////

        private void toolStripComboBoxStyle_Click(object sender, EventArgs e)
        {
            //if (toolStripComboBoxStyle.SelectedIndex == 0)//solid line
            //{
            //    style[0] = 0.1F;
            //    style[1] = 0.1F;
            //}
            //if (toolStripComboBoxStyle.SelectedIndex == 1)//dotted line
            //{
            //    style[0] = 0.25F;
            //    style[1] = 0.25F;
            //}
            //if (toolStripComboBoxStyle.SelectedIndex == 2)//dashed line
            //{
            //    style[0] = 0.50F;
            //    style[1] = 0.25F;
            //}
        }

        private void toolStripComboBoxSize_Click(object sender, EventArgs e)
        {
            //size = Convert.ToInt32(toolStripComboBoxSize.SelectedText);
        }

        private void toolStripComboBoxWidth_Click(object sender, EventArgs e)
        {
            //width = Convert.ToInt32(toolStripComboBoxWidth.SelectedText);
        }

        private void toolStripComboBoxShape_Click(object sender, EventArgs e)
        {
            //if (toolStripComboBoxShape.SelectedIndex == 0)
            //{ shape = 0; }
            //if (toolStripComboBoxShape.SelectedIndex == 1)
            //{ shape = 1; }
            //if (toolStripComboBoxShape.SelectedIndex == 2)
            //{ shape = 2; }
        }

        private void Draw_Click(object sender, EventArgs e)
        {            
            panel1.Refresh();            
            size = Convert.ToInt32(toolStripComboBoxSize.Text)+20;
            size_ = Convert.ToString(size);//////////
            width = Convert.ToInt32(toolStripComboBoxWidth.Text)+5;
            width_ = Convert.ToString(width);///////////
            if (toolStripComboBoxShape.SelectedIndex == 0)
            { shape = 0; }
            if (toolStripComboBoxShape.SelectedIndex == 1)
            { shape = 1; }
            if (toolStripComboBoxShape.SelectedIndex == 2)
            { shape = 2; }
            if (toolStripComboBoxStyle.SelectedIndex == 0)//style1
            {
                style[0] = 0.1F;
                style[1] = 0.1F;
                style_ = "1";//////////
            }
            if (toolStripComboBoxStyle.SelectedIndex == 1)//style2
            {
                style[0] = 0.25F;
                style[1] = 0.25F;
                style_ = "2";/////////
            }
            if (toolStripComboBoxStyle.SelectedIndex == 2)//style3
            {
                style[0] = 0.50F;
                style[1] = 0.25F;
                style_ = "3";/////////////
            }

            using (pen = new Pen(color, width))
            {
                pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Custom;
                pen.DashPattern = style;              
                Graphics graphics = panel1.CreateGraphics();
                /////////////////////////////////////////////////////////////////////////////////
                ////////////this is for making string to send 
                if (shape == 0)
                {
                    shape_ = "square";
                    finalString = shape_ +","+ style_+ "," + width_ + "," + size_ + "," + x_ + "," + y_ + ",";
                }
                if (shape == 1)
                {
                    shape_ = "circle";
                    finalString = shape_ + "," + style_ + "," + width_ + "," + size_ + "," + x_ + "," + y_ + ",";
                }
                if (shape == 2)
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    
                    shape_ = "polygon";
                    flag_ = Convert.ToString(flag);
                    for(int i =0;i<flag;i++)
                    {
                        stringBuilder.Append(X[i]);
                        stringBuilder.Append(",");
                    }
                    for (int i = 0; i < flag; i++)
                    {
                        stringBuilder.Append(Y[i]);
                        stringBuilder.Append(",");
                    }
                    string temp1 = stringBuilder.ToString();
                    finalString = shape_+ "," + style_ + "," + width_ + "," + flag_ + "," + temp1;
                }
                Send.Enabled = true;
                //////////////////////////////////////////////////////////////////////////////////
                            if (shape == 0)
                { graphics.DrawRectangle(pen, x, y, size, size);
                    flag = 0;
                    for (int j = 0; j < 10; j++)
                        X[j] = null;
                }
                if (shape == 1)
                { graphics.DrawEllipse(pen, x, y, size, size);
                    flag = 0;
                    for (int j = 0; j < 10; j++)
                        X[j] = null;
                }
                if (shape == 2)
                {
                    if (flag < 2)
                    {
                        MessageBox.Show("Minimum three points for a polygon");
                    }
                    else
                    {
                        for (int k = 0; k < flag - 1; k++)
                            graphics.DrawLine(pen, (int)X[k], (int)Y[k], (int)X[k + 1], (int)Y[k + 1]);
                        graphics.DrawLine(pen, (int)X[flag-1], (int)Y[flag-1], (int)X[0], (int)Y[0]);
                        flag = 0;

                    }
                }
            }
        }

        public Form1()
        {
            InitializeComponent();            
            toolStripComboBoxShape.SelectedIndex = 0;
            toolStripComboBoxSize.SelectedIndex = 0;
            toolStripComboBoxStyle.SelectedIndex = 0;
            toolStripComboBoxWidth.SelectedIndex = 0;
            color = Color.Black;
            ////////////////////////////////////////////////
            //t = new Thread(connect);

            iPEndPointServer = new IPEndPoint(ipAdressServer, portNoServer);
            iPEndPointClient = new IPEndPoint(ipAdressClient, portNoClient);
            // typecasting ipendpoint to endpoint
            remote = (EndPoint)iPEndPointClient;
            socket.Bind(iPEndPointServer);

            //t.Start();//starting connect function thread
        }

        private void connect()
        {
            try
            {
                while (true)
                {
                    ////recieve data from buffer and reading it 
                    ///////////////////////////////////////////
                    //socket.ReceiveFrom(bufferRecv, ref remote);//storing data coming from remote to bufferRecv
                    //dataRecv = Encoding.ASCII.GetString(bufferRecv);//converting byte data to string
                    ////to avoid threading exception
                    //if (InvokeRequired)
                    //{
                    //    BeginInvoke(new Action(() =>
                    //    {
                    //        temp = richTextBoxMsgWindow.Text;
                    //        richTextBoxMsgWindow.Text = temp + "\n" + "Client: " + dataRecv;
                    //    }));
                    //}
                    //else
                    //{
                    //    temp = richTextBoxMsgWindow.Text;
                    //    richTextBoxMsgWindow.Text = temp + dataRecv;
                    //}
                    //for (int i = 0; i < 1024; i++)
                    //    bufferRecv[i] = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection not established\n" + ex.Message);
            }
        }

        public void mouseClickStore(int x, int y)
        {
            if (flag < 10)
            {
                X[flag] = x;
                Y[flag] = y;
                X_[flag] = Convert.ToString(x);
                Y_[flag] = Convert.ToString(y);
                flag++;
            }
            else
            {
                MessageBox.Show("Max 10 points can be selected");
            }
        }
        private void colourToolStripMenuItem_Click(object sender, EventArgs e)
        { ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                color = colorDialog.Color;
                //string colorString = Convert.ToString(color);
                //MessageBox.Show(colorString);
                
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            x = e.X-size/2;
            y = e.Y-size/2;
            label1.Text = Convert.ToString(x);
            label2.Text = Convert.ToString(y);
            x_ = Convert.ToString(x);
            y_ = Convert.ToString(y);
            mouseClickStore(MousePosition.X - 121,MousePosition.Y-146);
        }

        private void toolStripComboBoxShape_Leave(object sender, EventArgs e)
        {
            //if (toolStripComboBoxShape.SelectedIndex == 2)
            //    toolStripComboBoxSize.Visible = false;
            //else
            //    toolStripComboBoxSize.Visible = true;
        }

        private void toolStripComboBoxShape_Validated(object sender, EventArgs e)
        {
            //if (toolStripComboBoxShape.SelectedIndex == 2)
            //    toolStripComboBoxSize.Visible = false;
            //else
            //    toolStripComboBoxSize.Visible = true;
        }

        private void toolStripComboBoxShape_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (toolStripComboBoxShape.SelectedIndex == 2)
            //    toolStripComboBoxSize.Visible = false;
            //else
            //    toolStripComboBoxSize.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Send_Click(object sender, EventArgs e)
        {
            try
            {
                //dataSend = textBoxTypeHere.Text;
                //MessageBox.Show(finalString);
                bufferSend = Encoding.ASCII.GetBytes(finalString);//converting string to byte datatype
                socket.SendTo(bufferSend, remote);//send buffersend to remote
                finalString = null;//clear textbox data 
                Send.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Send.Enabled = false;
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //aborting connect function
            t.Abort();
            //closing socket
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }
    }
}

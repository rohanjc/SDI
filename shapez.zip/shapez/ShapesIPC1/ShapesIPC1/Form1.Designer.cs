﻿namespace ShapesIPC1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.shapeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBoxShape = new System.Windows.Forms.ToolStripComboBox();
            this.styleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBoxStyle = new System.Windows.Forms.ToolStripComboBox();
            this.colourToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.widthToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBoxWidth = new System.Windows.Forms.ToolStripComboBox();
            this.sizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBoxSize = new System.Windows.Forms.ToolStripComboBox();
            this.Draw = new System.Windows.Forms.Button();
            this.Send = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 400);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shapeToolStripMenuItem,
            this.styleToolStripMenuItem1,
            this.colourToolStripMenuItem,
            this.widthToolStripMenuItem,
            this.sizeToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.menuStrip1.Location = new System.Drawing.Point(436, 16);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(77, 129);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // shapeToolStripMenuItem
            // 
            this.shapeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBoxShape});
            this.shapeToolStripMenuItem.Name = "shapeToolStripMenuItem";
            this.shapeToolStripMenuItem.Size = new System.Drawing.Size(67, 25);
            this.shapeToolStripMenuItem.Text = "Shape";
            // 
            // toolStripComboBoxShape
            // 
            this.toolStripComboBoxShape.Items.AddRange(new object[] {
            "Square",
            "Circle",
            "Polygen"});
            this.toolStripComboBoxShape.Name = "toolStripComboBoxShape";
            this.toolStripComboBoxShape.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBoxShape.ToolTipText = "Select type of shape";
            this.toolStripComboBoxShape.Leave += new System.EventHandler(this.toolStripComboBoxShape_Leave);
            this.toolStripComboBoxShape.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.toolStripComboBoxShape_KeyPress);
            this.toolStripComboBoxShape.Validated += new System.EventHandler(this.toolStripComboBoxShape_Validated);
            this.toolStripComboBoxShape.Click += new System.EventHandler(this.toolStripComboBoxShape_Click);
            // 
            // styleToolStripMenuItem1
            // 
            this.styleToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBoxStyle});
            this.styleToolStripMenuItem1.Name = "styleToolStripMenuItem1";
            this.styleToolStripMenuItem1.Size = new System.Drawing.Size(58, 25);
            this.styleToolStripMenuItem1.Text = "Style";
            this.styleToolStripMenuItem1.ToolTipText = "Select style of line";
            // 
            // toolStripComboBoxStyle
            // 
            this.toolStripComboBoxStyle.Items.AddRange(new object[] {
            "Style 1",
            "Style 2",
            "Style 3"});
            this.toolStripComboBoxStyle.Name = "toolStripComboBoxStyle";
            this.toolStripComboBoxStyle.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBoxStyle.Click += new System.EventHandler(this.toolStripComboBoxStyle_Click);
            // 
            // colourToolStripMenuItem
            // 
            this.colourToolStripMenuItem.Name = "colourToolStripMenuItem";
            this.colourToolStripMenuItem.Size = new System.Drawing.Size(71, 25);
            this.colourToolStripMenuItem.Text = "Colour";
            this.colourToolStripMenuItem.Click += new System.EventHandler(this.colourToolStripMenuItem_Click);
            // 
            // widthToolStripMenuItem
            // 
            this.widthToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBoxWidth});
            this.widthToolStripMenuItem.Name = "widthToolStripMenuItem";
            this.widthToolStripMenuItem.Size = new System.Drawing.Size(66, 25);
            this.widthToolStripMenuItem.Text = "Width";
            // 
            // toolStripComboBoxWidth
            // 
            this.toolStripComboBoxWidth.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.toolStripComboBoxWidth.Name = "toolStripComboBoxWidth";
            this.toolStripComboBoxWidth.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBoxWidth.ToolTipText = "Select width of line";
            this.toolStripComboBoxWidth.Click += new System.EventHandler(this.toolStripComboBoxWidth_Click);
            // 
            // sizeToolStripMenuItem
            // 
            this.sizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBoxSize});
            this.sizeToolStripMenuItem.Name = "sizeToolStripMenuItem";
            this.sizeToolStripMenuItem.Size = new System.Drawing.Size(51, 25);
            this.sizeToolStripMenuItem.Text = "Size";
            // 
            // toolStripComboBoxSize
            // 
            this.toolStripComboBoxSize.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.toolStripComboBoxSize.Name = "toolStripComboBoxSize";
            this.toolStripComboBoxSize.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBoxSize.ToolTipText = "Select size of shape";
            this.toolStripComboBoxSize.Click += new System.EventHandler(this.toolStripComboBoxSize_Click);
            // 
            // Draw
            // 
            this.Draw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Draw.Location = new System.Drawing.Point(436, 182);
            this.Draw.Name = "Draw";
            this.Draw.Size = new System.Drawing.Size(80, 40);
            this.Draw.TabIndex = 2;
            this.Draw.Text = "Draw";
            this.Draw.UseVisualStyleBackColor = true;
            this.Draw.Click += new System.EventHandler(this.Draw_Click);
            // 
            // Send
            // 
            this.Send.Enabled = false;
            this.Send.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Send.Location = new System.Drawing.Point(436, 225);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(80, 40);
            this.Send.TabIndex = 3;
            this.Send.Text = "Send";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(436, 286);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(436, 308);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 428);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Send);
            this.Controls.Add(this.Draw);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem shapeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem styleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem colourToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem widthToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxWidth;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxSize;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxShape;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxStyle;
        private System.Windows.Forms.Button Draw;
        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;        
    }
}


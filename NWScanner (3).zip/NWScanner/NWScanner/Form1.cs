﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Threading;
using System.Net;

namespace NWScanner
{
    public partial class FormNwScanner : Form
    {
        int cidrlength = 0;
        Thread t1;
        public FormNwScanner()
        {
            InitializeComponent();
        }
        public bool isValidaddress(string address)
        {
            try
            {
                bool isValid = false;
                string[] octetString = address.Split('.');
                int[] octet = new int[4];
                for (int i = 0; i < 4; i++)
                {
                    octet[i] = Convert.ToInt32(octetString[i]);
                    if (octet[i] < 256)
                        isValid = true;
                    else isValid = false;
                }
                return isValid;
            }
            catch 
            {
                return false;
            }
        }// check if octet value is less than 255
        public bool isValidSubnet(string subnet)
        {   try
            {   bool isvalid =true;
                string subnetBinary;
                string[] octetString = subnet.Split('.');
                string[] octetBinary =new string[4];
                int[] octet = new int[4];
                for (int i = 0; i < 4; i++)
                {
                    octet[i] = Convert.ToInt32(octetString[i]);
                    octetBinary[i] = Convert.ToString(octet[i], 2);
                }
                subnetBinary = octetBinary[0]+octetBinary[1]+octetBinary[2]+octetBinary[3];
                for (int i = 0; i < subnetBinary.Length-1; i++)
                {
                    if ( Convert.ToInt16(subnetBinary[i+1]) > Convert.ToInt16(subnetBinary[i]) )
                        isvalid = false;
                } return isvalid;
             }
            catch   {
                    return false;
                    }
        }
        public string NetworkAddressCal(string IPAdsress, string Subnet)
        {
            StringBuilder nwAddress = new StringBuilder();
            int[] octetIP = new int[4];
            int[] octetSubnet = new int[4];
            string[] ipBinary = new string[4];
            string[] ipBinaryPadded = new string[4];
            string[] subnetBinary = new string[4]; ;
            string[] ipOctetString = IPAdsress.Split('.');
            string[] subnetOctetString = Subnet.Split('.');
            for (int i = 0; i < 4; i++)
            {
                octetIP[i] = Convert.ToInt16(ipOctetString[i]);
                octetSubnet[i] = Convert.ToInt16(subnetOctetString[i]);
                ipBinary[i] = Convert.ToString(octetIP[i],2);
                subnetBinary[i] = Convert.ToString(octetSubnet[i],2);
            }
           
            //ip octet needs to be padded individualy to left
            ipBinaryPadded[0]= ipBinary[0].PadLeft(8, '0');
            ipBinaryPadded[1]= ipBinary[1].PadLeft(8, '0');
            ipBinaryPadded[2]= ipBinary[2].PadLeft(8, '0');
            ipBinaryPadded[3]= ipBinary[3].PadLeft(8, '0');
            string ipBinaryString = ipBinaryPadded[0]+ ipBinaryPadded[1]+ ipBinaryPadded[2]+ ipBinaryPadded[3];

            //subnet octet can be padded together to right
            string subnet = subnetBinary[0] + subnetBinary[1] + subnetBinary[2] + subnetBinary[3];           
            string subnetBinaryString = subnet.PadRight(32,'0');
           
            //MessageBox.Show(ipBinaryString+"\n"+subnetBinaryString);
            //calculating cidr here
            for (int i = 0; i < subnetBinaryString.Length; i++)
                if( subnetBinaryString[i] == '1' )
                    cidrlength++;

            string temp = ipBinaryString;
           // MessageBox.Show(Convert.ToString(cidrlength));

            for (int i = 0; i < cidrlength; i++)
            {
                nwAddress.Append(temp[i]);
            }
            for (int i = 0; i < 32 - cidrlength; i++)
            {
                nwAddress.Append('0');
            }
            string networkAddress = nwAddress.ToString();
                //MessageBox.Show("SM\t"+subnetBinaryString+ "\n" +"IP\t"+ipBinaryString+ "\n" +"NW\t"+networkAddress);
            return networkAddress;
        }
        public bool pingResult(string ipAddress)
        {
            bool isPinging = false;
            Ping ping = null;
            try 
            {
                ping = new Ping();
                PingReply pingReply = ping.Send(ipAddress);
                isPinging = (pingReply.Status == IPStatus.Success);
            }
            catch { }
            finally 
            {
                if (isPinging != null)
                    ping.Dispose();
            }
            return isPinging;
        }       
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void buttonScan_Click_1(object sender, EventArgs e)
        {
            listViewAllIp.Items.Clear();
            bool isCorrectIP = false;
            bool isCorrectSubnet = false;
            string nwAddress = "";//for storing complete nw address in binary
            string[] nwAddressOctet = new string[4];//for storing binary octets in each string of string array
            string IPAddress = maskedTextBoxIPAddress.Text;
            string subnet = maskedTextBoxSubnet.Text;

            isCorrectSubnet = isValidSubnet(subnet) && isValidaddress(subnet);
            if (isCorrectSubnet)
            { //MessageBox.Show("correctSubnet"); 
            }
            else
            { MessageBox.Show("wrongSubnet"); }
            isCorrectIP = isValidaddress(IPAddress);
            if(isCorrectIP)
            { //MessageBox.Show("correctIP"); 
            }
            else
            { MessageBox.Show("wrongIP"); }
            //MessageBox.Show(Convert.ToString(isCorrectIP) + Convert.ToString(isCorrectSubnet)); // 

            if (isCorrectIP && isCorrectSubnet)
            {
                nwAddress = NetworkAddressCal(IPAddress, subnet);

                nwAddressOctet[0] = nwAddress.Substring(0, 8);
                nwAddressOctet[1] = nwAddress.Substring(8, 8);
                nwAddressOctet[2] = nwAddress.Substring(16, 8);
                nwAddressOctet[3] = nwAddress.Substring(24, 8);

                int octet0 = Convert.ToInt16(nwAddressOctet[0], 2);
                int octet1 = Convert.ToInt16(nwAddressOctet[1], 2);
                int octet2 = Convert.ToInt16(nwAddressOctet[2], 2);
                int octet3 = Convert.ToInt16(nwAddressOctet[3], 2);

                double noOfhosts = Math.Pow (2, (32-cidrlength+1) )-2 ;
                //MessageBox.Show(Convert.ToString(noOfhosts));
                for (int i = 1; i <= noOfhosts; i++)
                {
                    if (octet3 < 256)
                    {
                        octet3++;
                    }
                    else if (octet3 == 256)
                    {
                        if (octet2 < 256)
                        {
                            octet3 = 0;
                            octet2++;
                        }
                        else if (octet2 == 256)
                        {
                            if (octet1 < 256)
                            {
                                octet2 = 0;
                                octet1++;
                            }
                            else if (octet1 == 256)
                            {
                                octet0++;
                                octet1 = 0;
                            }
                        }
                    }
                    string hostAddress = Convert.ToString(octet0) + "." + Convert.ToString(octet1) + "." + Convert.ToString(octet2) + "." + Convert.ToString(octet3);
                    //Console.Write(hostAddress+" ");
                    listViewAllIp.Items.Add(hostAddress);
                    //if (pingResult(hostAddress) == true)
                    //{
                    //Console.WriteLine(hostAddress + " success");
                    //listViewIP.Items.Add(hostAddress + "Sucess");
                    //}
                    //else
                    //{
                    //Console.WriteLine(hostAddress + " fail");
                    //listViewIP.Items.Add(hostAddress + " Fail");
                    //}
                }
            }
            cidrlength = 0;
        }
        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listViewIP_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonScanAll_Click(object sender, EventArgs e)
        {
            t1 = new Thread(scanIPs);
            t1.Start();      
                    
        }

        private void scanIPs()
        {
            
            {
                int i = 0;
                if (InvokeRequired)                
                BeginInvoke(new Action(() =>
                {
                    foreach (ListViewItem item in listViewAllIp.Items)
                    {
                        if (pingResult(listViewAllIp.Items[i].ToString()) == true)
                            listViewConnectedIp.Items.Add(listViewAllIp.Items[i].ToString());
                        //else
                        //    listViewConnectedIp.Items.Add(listViewAllIp.Items[i].Text + "fail");
                        //i++;
                    }

                }));
                
                
            }
        }

        private void buttonScanSelection_Click(object sender, EventArgs e)
        {
            string hostadress = listViewAllIp.SelectedItems[0].Text;
            MessageBox.Show(hostadress);
            if (pingResult(hostadress) == true)
                listViewConnectedIp.Items.Add(hostadress);
            else
                listViewConnectedIp.Items.Add(hostadress+" Not Connecetd");

        }

        private void buttonPortScan_Click(object sender, EventArgs e)
        {
            IPAddress iPAddress = IPAddress.Parse(listViewConnectedIp.SelectedItems[0].Text);
            for (int i = 0; i < 6; i++)
            {
                try
                {
                    System.Net.Sockets.Socket sock = new System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp);
                    sock.Connect(iPAddress, i);
                        if(sock.Connected == true) ;
                }
                catch(System.Net.Sockets.SocketException ex)
                {
                    if (ex.ErrorCode == 10061)
                        listViewPorts.Items.Add(Convert.ToString(i));
                }
            }
        }
    }
}

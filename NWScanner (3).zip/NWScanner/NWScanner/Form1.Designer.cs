﻿namespace NWScanner
{
    partial class FormNwScanner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.maskedTextBoxIPAddress = new System.Windows.Forms.MaskedTextBox();
            this.labelIPAdress = new System.Windows.Forms.Label();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.maskedTextBoxSubnet = new System.Windows.Forms.MaskedTextBox();
            this.listViewAllIp = new System.Windows.Forms.ListView();
            this.labelIPlistview = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonScanAll = new System.Windows.Forms.Button();
            this.buttonScanSelection = new System.Windows.Forms.Button();
            this.listViewConnectedIp = new System.Windows.Forms.ListView();
            this.listViewPorts = new System.Windows.Forms.ListView();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonPortScan = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // maskedTextBoxIPAddress
            // 
            this.maskedTextBoxIPAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.maskedTextBoxIPAddress.Location = new System.Drawing.Point(116, 7);
            this.maskedTextBoxIPAddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.maskedTextBoxIPAddress.Mask = "000.000.000.000";
            this.maskedTextBoxIPAddress.Name = "maskedTextBoxIPAddress";
            this.maskedTextBoxIPAddress.Size = new System.Drawing.Size(139, 26);
            this.maskedTextBoxIPAddress.TabIndex = 0;
            this.maskedTextBoxIPAddress.Text = "192168001003";
            this.maskedTextBoxIPAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelIPAdress
            // 
            this.labelIPAdress.AutoSize = true;
            this.labelIPAdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelIPAdress.Location = new System.Drawing.Point(25, 10);
            this.labelIPAdress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIPAdress.Name = "labelIPAdress";
            this.labelIPAdress.Size = new System.Drawing.Size(87, 20);
            this.labelIPAdress.TabIndex = 1;
            this.labelIPAdress.Text = "IP Address";
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonCalculate.Location = new System.Drawing.Point(269, 7);
            this.buttonCalculate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(104, 53);
            this.buttonCalculate.TabIndex = 2;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonScan_Click_1);
            // 
            // maskedTextBoxSubnet
            // 
            this.maskedTextBoxSubnet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.maskedTextBoxSubnet.Location = new System.Drawing.Point(116, 37);
            this.maskedTextBoxSubnet.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBoxSubnet.Mask = "000.000.000.000";
            this.maskedTextBoxSubnet.Name = "maskedTextBoxSubnet";
            this.maskedTextBoxSubnet.Size = new System.Drawing.Size(139, 26);
            this.maskedTextBoxSubnet.TabIndex = 1;
            this.maskedTextBoxSubnet.Text = "255255255000";
            this.maskedTextBoxSubnet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // listViewAllIp
            // 
            this.listViewAllIp.Location = new System.Drawing.Point(18, 98);
            this.listViewAllIp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.listViewAllIp.Name = "listViewAllIp";
            this.listViewAllIp.Size = new System.Drawing.Size(237, 389);
            this.listViewAllIp.TabIndex = 3;
            this.listViewAllIp.UseCompatibleStateImageBehavior = false;
            this.listViewAllIp.View = System.Windows.Forms.View.List;
            this.listViewAllIp.SelectedIndexChanged += new System.EventHandler(this.listViewIP_SelectedIndexChanged);
            // 
            // labelIPlistview
            // 
            this.labelIPlistview.AutoSize = true;
            this.labelIPlistview.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelIPlistview.Location = new System.Drawing.Point(344, 79);
            this.labelIPlistview.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIPlistview.Name = "labelIPlistview";
            this.labelIPlistview.Size = new System.Drawing.Size(116, 17);
            this.labelIPlistview.TabIndex = 5;
            this.labelIPlistview.Text = "Connected Hosts";
            this.labelIPlistview.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(9, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Subnet Mask";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(76, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "All Possible hosts";
            // 
            // buttonScanAll
            // 
            this.buttonScanAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonScanAll.Location = new System.Drawing.Point(379, 7);
            this.buttonScanAll.Name = "buttonScanAll";
            this.buttonScanAll.Size = new System.Drawing.Size(104, 53);
            this.buttonScanAll.TabIndex = 8;
            this.buttonScanAll.Text = "Scan All";
            this.buttonScanAll.UseVisualStyleBackColor = true;
            this.buttonScanAll.Click += new System.EventHandler(this.buttonScanAll_Click);
            // 
            // buttonScanSelection
            // 
            this.buttonScanSelection.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonScanSelection.Location = new System.Drawing.Point(489, 7);
            this.buttonScanSelection.Name = "buttonScanSelection";
            this.buttonScanSelection.Size = new System.Drawing.Size(104, 53);
            this.buttonScanSelection.TabIndex = 9;
            this.buttonScanSelection.Text = "Scan Selection";
            this.buttonScanSelection.UseVisualStyleBackColor = true;
            this.buttonScanSelection.Click += new System.EventHandler(this.buttonScanSelection_Click);
            // 
            // listViewConnectedIp
            // 
            this.listViewConnectedIp.Location = new System.Drawing.Point(280, 98);
            this.listViewConnectedIp.Margin = new System.Windows.Forms.Padding(2);
            this.listViewConnectedIp.Name = "listViewConnectedIp";
            this.listViewConnectedIp.Size = new System.Drawing.Size(237, 389);
            this.listViewConnectedIp.TabIndex = 10;
            this.listViewConnectedIp.UseCompatibleStateImageBehavior = false;
            this.listViewConnectedIp.View = System.Windows.Forms.View.List;
            // 
            // listViewPorts
            // 
            this.listViewPorts.Location = new System.Drawing.Point(543, 98);
            this.listViewPorts.Margin = new System.Windows.Forms.Padding(2);
            this.listViewPorts.Name = "listViewPorts";
            this.listViewPorts.Size = new System.Drawing.Size(237, 389);
            this.listViewPorts.TabIndex = 11;
            this.listViewPorts.UseCompatibleStateImageBehavior = false;
            this.listViewPorts.View = System.Windows.Forms.View.List;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(593, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Port of Connected Hosts";
            // 
            // buttonPortScan
            // 
            this.buttonPortScan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonPortScan.Location = new System.Drawing.Point(599, 7);
            this.buttonPortScan.Name = "buttonPortScan";
            this.buttonPortScan.Size = new System.Drawing.Size(104, 53);
            this.buttonPortScan.TabIndex = 13;
            this.buttonPortScan.Text = "Scan Port";
            this.buttonPortScan.UseVisualStyleBackColor = true;
            this.buttonPortScan.Click += new System.EventHandler(this.buttonPortScan_Click);
            // 
            // FormNwScanner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 498);
            this.Controls.Add(this.buttonPortScan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listViewPorts);
            this.Controls.Add(this.listViewConnectedIp);
            this.Controls.Add(this.buttonScanSelection);
            this.Controls.Add(this.buttonScanAll);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelIPlistview);
            this.Controls.Add(this.listViewAllIp);
            this.Controls.Add(this.maskedTextBoxSubnet);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.labelIPAdress);
            this.Controls.Add(this.maskedTextBoxIPAddress);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FormNwScanner";
            this.Text = "NW Scanner";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox maskedTextBoxIPAddress;
        private System.Windows.Forms.Label labelIPAdress;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxSubnet;
        private System.Windows.Forms.ListView listViewAllIp;
        private System.Windows.Forms.Label labelIPlistview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonScanAll;
        private System.Windows.Forms.Button buttonScanSelection;
        private System.Windows.Forms.ListView listViewConnectedIp;
        private System.Windows.Forms.ListView listViewPorts;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonPortScan;
    }
}


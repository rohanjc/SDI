﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickSort
{
    class Program
    {
        int[] arr = new int[] { 10, 16, 8, 12, 15, 6, 3, 9, 5 };
        public void QuickSortAlgorithm(int low, int high)
        {
            if(low<high)
            {
                //Partition function returns the partition or place where first sorted element is placed
                int j = Partition(low, high);
                //Perform Quick sort from low to partiton
                QuickSortAlgorithm(low, j-1);
                //Perform Quick sort from partiton to high
                QuickSortAlgorithm(j+1, high);
            }
        }
        public int Partition(int low,int high)
        {
            // Selecting first element as the pivot
            int pivot = arr[low];
            // initialising counter from second number and other counter from last number
            int i = low+1, j = high;           
            
            while (i <= j)
            {
                // Finding correct sorted position of pivot
                while (arr[i] <= pivot)               
                    i++;
                
                while (arr[j] > pivot)
                    j--;              
                // Swaping the elements of array till all elements to left of pivot are smaller than
                // than pivot and all elements on right are greater than pivot
                if (i < j)
                {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
            // Positioning pivot at correct position
            int temp1 = arr[low];
            arr[low] = arr[j];
            arr[j] = temp1;
            return j;
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.QuickSortAlgorithm(0, obj.arr.Length-1);

            for (int i = 0; i < obj.arr.Length; i++)            
                Console.WriteLine(obj.arr[i]);
            Console.ReadLine();
        }
    }
}
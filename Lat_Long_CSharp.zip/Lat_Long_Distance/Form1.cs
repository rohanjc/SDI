﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Let_Long_Sparsh_Sir
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            string[] lat_1 = maskedTextBox1.Text.Split(':');
            string[] long_1 = maskedTextBox2.Text.Split(':');

            float lat1_deg_deg_sec = (float)Convert.ToDouble(lat_1[0]);
            float lat1_min_deg_sec = (float)Convert.ToDouble(lat_1[1]);
            float lat1_sec_deg_sec = (float)Convert.ToDouble(lat_1[2]);

            if ((lat1_deg_deg_sec < 0 || lat1_deg_deg_sec > 90) || (lat1_min_deg_sec < 0 || lat1_min_deg_sec > 60) || (lat1_sec_deg_sec < 0 || lat1_sec_deg_sec > 60))

                MessageBox.Show("Enter Valid inputs");
            else
            {
                lat1_min_deg_sec /= 60;
                lat1_sec_deg_sec /= 360;

                textBox2.Text = (lat1_deg_deg_sec + lat1_min_deg_sec + lat1_sec_deg_sec + " Deg");
            }
                float long1_deg_deg_sec = (float)Convert.ToDouble(long_1[0]);
                float long1_min_deg_sec = (float)Convert.ToDouble(long_1[1]);
                float long1_sec_deg_sec = (float)Convert.ToDouble(long_1[2]);

            if ((long1_deg_deg_sec < 0 || long1_deg_deg_sec > 90) || (long1_min_deg_sec < 0 || long1_min_deg_sec > 60) || (long1_sec_deg_sec < 0 || long1_sec_deg_sec > 60))

                MessageBox.Show("Enter Valid inputs");

            else
            {
                long1_min_deg_sec /= 60;
                long1_sec_deg_sec /= 360;

                textBox3.Text = (long1_deg_deg_sec + long1_min_deg_sec + long1_sec_deg_sec + " Deg");
            }
                //For the Second Co-Ordinate

                string[] lat_2 = maskedTextBox3.Text.Split(':');
                string[] long_2 = maskedTextBox4.Text.Split(':');

                float lat2_deg_deg_sec = (float)Convert.ToDouble(lat_2[0]);
                float lat2_min_deg_sec = (float)Convert.ToDouble(lat_2[1]);
                float lat2_sec_deg_sec = (float)Convert.ToDouble(lat_2[2]);

            if ((lat2_deg_deg_sec < 0 || lat2_deg_deg_sec > 90) || (lat2_min_deg_sec < 0 || lat2_min_deg_sec > 60) || (lat2_sec_deg_sec < 0 || lat2_sec_deg_sec > 60))

                MessageBox.Show("Enter Valid inputs");
            else
            {
                lat2_min_deg_sec /= 60;
                lat2_sec_deg_sec /= 360;

                textBox4.Text = (lat2_deg_deg_sec + lat2_min_deg_sec + lat2_sec_deg_sec + " Deg");
            }
             
            
                float long2_deg_deg_sec = (float)Convert.ToDouble(long_2[0]);
                float long2_min_deg_sec = (float)Convert.ToDouble(long_2[1]);
                float long2_sec_deg_sec = (float)Convert.ToDouble(long_2[2]);
            if ((long2_deg_deg_sec < 0 || long2_deg_deg_sec > 90) || (long2_min_deg_sec < 0 || long2_min_deg_sec > 60) || (long2_sec_deg_sec < 0 || long2_sec_deg_sec > 60))

                MessageBox.Show("Enter Valid inputs");
            else
            {
                long2_min_deg_sec /= 60;
                long2_sec_deg_sec /= 360;
                textBox5.Text = (long2_deg_deg_sec + long2_min_deg_sec + long2_sec_deg_sec + " Deg");
            }
        }
            private void radioButton2_CheckedChanged(object sender, EventArgs e)
            {
                string[] laty_1 = maskedTextBox1.Text.Split(':');
                string[] longy_1 = maskedTextBox2.Text.Split(':');

            float lat1_deg_deg_min = (float)Convert.ToDouble(laty_1[0]);
            float lat1_min_deg_min = (float)Convert.ToDouble(laty_1[1]);
            float lat1_sec_deg_min = (float)Convert.ToDouble(laty_1[2]);

            if ((lat1_deg_deg_min < 0 || lat1_deg_deg_min > 90) || (lat1_min_deg_min < 0 || lat1_min_deg_min > 60) || (lat1_sec_deg_min < 0 || lat1_sec_deg_min > 60))
                MessageBox.Show("Enter Valid inputs");
            else
            {
                lat1_sec_deg_min /= 60;
                lat1_min_deg_min += lat1_sec_deg_min;
            }
            textBox2.Text = (lat1_deg_deg_min + " Deg " + lat1_min_deg_min + " Min ");

            float long1_deg_deg_min = (float)Convert.ToDouble(longy_1[0]);
            float long1_min_deg_min = (float)Convert.ToDouble(longy_1[1]);
            float long1_sec_deg_min = (float)Convert.ToDouble(longy_1[2]);

            if ((long1_deg_deg_min < 0 || long1_deg_deg_min > 90) || (long1_min_deg_min < 0 || long1_min_deg_min > 60) || (long1_sec_deg_min < 0 || long1_sec_deg_min > 60))

                MessageBox.Show("Enter Valid inputs");
            else
            {
                long1_sec_deg_min /= 60;
                long1_min_deg_min += long1_sec_deg_min;

                textBox3.Text = (long1_deg_deg_min + " Deg " + long1_min_deg_min + " Min ");
            }
            //For the Second Co-Ordinate

            string[] lat_2 = maskedTextBox3.Text.Split(':');
            string[] long_2 = maskedTextBox4.Text.Split(':');

            float lat2_deg_deg_min = (float)Convert.ToDouble(lat_2[0]);
            float lat2_min_deg_min = (float)Convert.ToDouble(lat_2[1]);
            float lat2_sec_deg_min = (float)Convert.ToDouble(lat_2[2]);

            if ((lat2_deg_deg_min < 0 || lat2_deg_deg_min > 90) || (lat2_min_deg_min < 0 || lat2_min_deg_min > 60) || (lat2_sec_deg_min < 0 || lat2_sec_deg_min > 60))
                MessageBox.Show("Enter Valid inputs");
            else
            {
                lat2_sec_deg_min /= 60;
                lat2_min_deg_min += lat2_sec_deg_min;
            }

            textBox4.Text = (lat2_deg_deg_min + " Deg " + lat2_min_deg_min + " Min ");

            float long2_deg_deg_min = (float)Convert.ToDouble(long_2[0]);
            float long2_min_deg_min = (float)Convert.ToDouble(long_2[1]);
            float long2_sec_deg_min = (float)Convert.ToDouble(long_2[2]);

            if ((long2_deg_deg_min < 0 || long2_deg_deg_min > 90) || (long2_min_deg_min < 0 || long2_min_deg_min > 60) || (long2_sec_deg_min < 0 || long2_sec_deg_min > 60))

                MessageBox.Show("Enter Valid inputs");
            else
            {
                long2_sec_deg_min /= 60;
                long2_min_deg_min += long2_sec_deg_min;


                textBox5.Text = (long2_deg_deg_min + " Deg " + long2_min_deg_min + " Min ");
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            string[] lat_1 = maskedTextBox1.Text.Split(':');
            string[] long_1 = maskedTextBox2.Text.Split(':');

            float lat1_deg_deg_min = (float)Convert.ToDouble(lat_1[0]);
            float lat1_min_deg_min = (float)Convert.ToDouble(lat_1[1]);
            float lat1_sec_deg_min = (float)Convert.ToDouble(lat_1[2]);

            if ((lat1_deg_deg_min < 0 || lat1_deg_deg_min > 90) || (lat1_min_deg_min < 0 || lat1_min_deg_min > 60) || (lat1_sec_deg_min < 0 || lat1_sec_deg_min > 60))
                MessageBox.Show("Enter Valid inputs");
            else
            textBox2.Text = (lat1_deg_deg_min + " Deg " + lat1_min_deg_min + " Min " + lat1_sec_deg_min + " Sec");

            float long1_deg_deg_min = (float)Convert.ToDouble(long_1[0]);
            float long1_min_deg_min = (float)Convert.ToDouble(long_1[1]);
            float long1_sec_deg_min = (float)Convert.ToDouble(long_1[2]);

            if ((lat1_deg_deg_min < 0 || lat1_deg_deg_min > 90) || (lat1_min_deg_min < 0 || lat1_min_deg_min > 60) || (lat1_sec_deg_min < 0 || lat1_sec_deg_min > 60))
                MessageBox.Show("Enter Valid inputs");
            else
                textBox3.Text = (long1_deg_deg_min + " Deg " + long1_min_deg_min + " Min " + long1_sec_deg_min + " Sec");

            //For the Second Co-Ordinate

            string[] lat_2 = maskedTextBox3.Text.Split(':');
            string[] long_2 = maskedTextBox4.Text.Split(':');

            float lat2_deg_deg_min = (float)Convert.ToDouble(lat_2[0]);
            float lat2_min_deg_min = (float)Convert.ToDouble(lat_2[1]);
            float lat2_sec_deg_min = (float)Convert.ToDouble(lat_2[2]);
            if ((lat2_deg_deg_min < 0 || lat2_deg_deg_min > 90) || (lat2_min_deg_min < 0 || lat2_min_deg_min > 60) || (lat2_sec_deg_min < 0 || lat2_sec_deg_min > 60))
                MessageBox.Show("Enter Valid inputs");
            else
            textBox4.Text = (lat2_deg_deg_min + " Deg " + lat2_min_deg_min + " Min " + lat2_sec_deg_min + " Sec ");

            float long2_deg_deg_min = (float)Convert.ToDouble(long_2[0]);
            float long2_min_deg_min = (float)Convert.ToDouble(long_2[1]);
            float long2_sec_deg_min = (float)Convert.ToDouble(long_2[2]);

            if ((long2_deg_deg_min < 0 || long2_deg_deg_min > 90) || (long2_min_deg_min < 0 || long2_min_deg_min > 60) || (long2_sec_deg_min < 0 || long2_sec_deg_min > 60))
                MessageBox.Show("Enter Valid inputs");
            else

                textBox5.Text = (long2_deg_deg_min + " Deg " + long2_min_deg_min + " Min " + long2_sec_deg_min + " Sec ");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float radius = 6400;
            string[] lat_1 = maskedTextBox1.Text.Split(':');
            string[] long_1 = maskedTextBox2.Text.Split(':');

            float lat1_deg_deg_sec = (float)Convert.ToDouble(lat_1[0]);
            float lat1_min_deg_sec = (float)Convert.ToDouble(lat_1[1]);
            float lat1_sec_deg_sec = (float)Convert.ToDouble(lat_1[2]);

            
                lat1_min_deg_sec /= 60;
                lat1_sec_deg_sec /= 360;

                float lat1 = lat1_deg_deg_sec + lat1_min_deg_sec + lat1_sec_deg_sec;
            
            float long1_deg_deg_sec = (float)Convert.ToDouble(long_1[0]);
            float long1_min_deg_sec = (float)Convert.ToDouble(long_1[1]);
            float long1_sec_deg_sec = (float)Convert.ToDouble(long_1[2]);

           
                long1_min_deg_sec /= 60;
                long1_sec_deg_sec /= 360;

                float long1 = long1_deg_deg_sec + long1_min_deg_sec + long1_sec_deg_sec;
            
            //For the Second Co-Ordinate

            string[] lat_2 = maskedTextBox3.Text.Split(':');
            string[] long_2 = maskedTextBox4.Text.Split(':');

            float lat2_deg_deg_sec = (float)Convert.ToDouble(lat_2[0]);
            float lat2_min_deg_sec = (float)Convert.ToDouble(lat_2[1]);
            float lat2_sec_deg_sec = (float)Convert.ToDouble(lat_2[2]);

            
                lat2_min_deg_sec /= 60;
                lat2_sec_deg_sec /= 360;

                float lat2 = lat2_deg_deg_sec + lat2_min_deg_sec + lat2_sec_deg_sec;
            
            float long2_deg_deg_sec = (float)Convert.ToDouble(long_2[0]);
            float long2_min_deg_sec = (float)Convert.ToDouble(long_2[1]);
            float long2_sec_deg_sec = (float)Convert.ToDouble(long_2[2]); 

                long2_min_deg_sec /= 60;
                long2_sec_deg_sec /= 360;

                float long2 = long2_deg_deg_sec + long2_min_deg_sec + long2_sec_deg_sec;
            

            float dlat = (lat2 - lat1)/2;
            float dlong = (long2 - long1)/2;

            float first_part = (float)Math.Pow(Math.Sin(dlat), 2);
            float second_part = (float)(Math.Cos(lat1) * Math.Cos(lat2) * (Math.Pow(Math.Sin(dlong), 2)));

            float resulting = (float)Math.Sqrt(first_part + second_part);

            float distance = (float )(2 * radius * Math.Asin(resulting));
            
            textBox1.Text = distance+ " Kms";
        }

        
    }

    }

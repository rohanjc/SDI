﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Pen Red = new Pen(Color.Red);
        Pen Green = new Pen(Color.Green);
        Pen Black = new Pen(Color.Black);
        System.Drawing.SolidBrush fillred = new System.Drawing.SolidBrush(Color.Red);
        System.Drawing.SolidBrush fillyellow = new System.Drawing.SolidBrush(Color.Yellow);
        System.Drawing.SolidBrush fillblack = new System.Drawing.SolidBrush(Color.Black);


        Rectangle Rect = new Rectangle(20, 20, 220, 90);
        Rectangle Circle = new Rectangle(20, 20, 220, 220);
        Rectangle Point = new Rectangle(150, 150, 10, 10);
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawRectangle(Red, Rect);
            g.DrawEllipse(Green, Circle);
            g.DrawEllipse(Black, Point);

            g.FillEllipse(fillblack, Point);
        }
    }
}

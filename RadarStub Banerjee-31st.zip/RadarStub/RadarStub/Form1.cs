﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace RadarStub
{
    public partial class FormRadarStub : Form
    {
        string dataSend;
        byte[] bufferSend = new byte[1024];
        IPAddress ipAdressServer = IPAddress.Parse("10.11.30.194");
        IPAddress ipAdressClient = IPAddress.Parse("10.11.30.194");
        int portNoServer = Convert.ToInt32(45001);
        int portNoClient = Convert.ToInt32(45002);
        IPEndPoint iPEndPointServer;
        IPEndPoint iPEndPointClient;
        EndPoint remote;
        Thread t;
        //creating a new socket 
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        ////////////////////////////////////////////////////////////////////////////////////
        double initialLat; //= 45.000000;
        double initialLong; //= 45.000000;
        double groundSpeed; //= 555; //kmph, aircraft bearing towards north
        double groundspeedMPSLat;
        double groundspeedMPSLong;
        double currentLatitude;
        double currentLongitude;
        double bearing;
        double bearingRadian;
        double heading;
        double rateOfturn;
        double radius = 6320000;
        int i = 0;
        int indicator = 0; //flag for cloud data
        bool flag = true;
        string point1, point2, point3, point4, point5, point6, point7, point8, point9, point10, intensity, cloudId, final_cloud;
        double latFactor, longFactor;
        private void comboBoxCloudId_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxCloudId.Text == "1")
            {
                latFactor = 1.5;
                longFactor = - 0.5;
                getCloud(latFactor, longFactor);
            }
            else if(comboBoxCloudId.Text == "2")
            {
                latFactor = 1.5;
                longFactor = - 0.5;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "3")
            {
                latFactor = 1.5;
                longFactor = -0.5;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "4")
            {
                latFactor = 1.5;
                longFactor = 0.5;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "5")
            {
                latFactor = 1.5;
                longFactor = 0.5;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "6")
            {
                latFactor = 1.5;
                longFactor = 0.5;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "7")
            {
                latFactor = 1;
                longFactor = 0;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "8")
            {
                latFactor = 1;
                longFactor = 0;
                getCloud(latFactor, longFactor);
            }
            else if (comboBoxCloudId.Text == "9")
            {
                latFactor = 1;
                longFactor = 0;
                getCloud(latFactor, longFactor);
            }
        }

        //Function added to fill up textboxes with fresh data points
        public void getCloud(double up, double side)
        {
            //setting up intensity combobox
            if (comboBoxCloudId.SelectedIndex == 0 || comboBoxCloudId.SelectedIndex == 3 || comboBoxCloudId.SelectedIndex == 6)
                comboBoxIntensity.SelectedIndex = 0;
            else if (comboBoxCloudId.SelectedIndex == 1 || comboBoxCloudId.SelectedIndex == 4 || comboBoxCloudId.SelectedIndex == 7)
                comboBoxIntensity.SelectedIndex = 1;
            else if (comboBoxCloudId.SelectedIndex == 2 || comboBoxCloudId.SelectedIndex == 5 || comboBoxCloudId.SelectedIndex == 8)
                comboBoxIntensity.SelectedIndex = 2;

            //reading the indexes from the earlier sections
            double indexLat = 45 + up;
            double indexLong = 45 + side;
            //Random number generator
            Random seed = new Random();
            
            //filling up latitude textboxes
            textBoxLat1.Text = Convert.ToString(indexLat);
            textBoxLat2.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat3.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat4.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat5.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat6.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat7.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat8.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat9.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            textBoxLat10.Text = Convert.ToString(indexLat + (seed.NextDouble())/4);
            
            //Filling up longitude textboxes
            textBoxLong1.Text = Convert.ToString(indexLong);
            textBoxLong2.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong3.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong4.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong5.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong6.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong7.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong8.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong9.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
            textBoxLong10.Text = Convert.ToString(indexLong + (seed.NextDouble())/4);
        }

        private void textBoxLat4_TextChanged(object sender, EventArgs e)
        {

        }

        //parameters added for receiving cloud data
        //double cldLat1, cldLat2, cldLat3, cldLat4, cldLat5;
        //double cldLong1, cldLong2, cldLong3, cldLong4, cldLong5;
        //double cldHt1, cldHt2, cldHt3, cldHt4, cldHt5;
        //double cldInt1, cldInt2, cldInt3, cldInt4, cldInt5;

        //button added for updating cloud data
        private void buttonUpdateCloudData_Click(object sender, EventArgs e)
        {
            //cldLat1 = Convert.ToDouble(textBoxLat1.Text);
            //cldLong1 = Convert.ToDouble(textBoxLat1.Text);
            //cldHt1 = Convert.ToDouble(textBoxLat1.Text);
            //cldInt1 = Convert.ToDouble(textBoxLat1.Text);


            //cldLat2 = Convert.ToDouble(textBoxLat2.Text);
            //cldLong2 = Convert.ToDouble(textBoxLat2.Text);
            //cldHt2 = Convert.ToDouble(textBoxLat2.Text);
            //cldInt2 = Convert.ToDouble(textBoxLat2.Text);

            //cldLat3 = Convert.ToDouble(textBoxLat3.Text);
            //cldLong3 = Convert.ToDouble(textBoxLat3.Text);
            //cldHt3 = Convert.ToDouble(textBoxLat3.Text);
            //cldInt3 = Convert.ToDouble(textBoxLat3.Text);

            //cldLat4 = Convert.ToDouble(textBoxLat4.Text);
            //cldLong4 = Convert.ToDouble(textBoxLat4.Text);
            //cldHt4 = Convert.ToDouble(textBoxLat4.Text);
            //cldInt4 = Convert.ToDouble(textBoxLat4.Text);

            //cldLat5 = Convert.ToDouble(textBoxLat5.Text);
            //cldLong5 = Convert.ToDouble(textBoxLat5.Text);
            //cldHt5 = Convert.ToDouble(textBoxLat5.Text);
            //cldInt5 = Convert.ToDouble(textBoxLat5.Text);

        }

        ///////////////////////////////////////////////////////////////////////////////////


        public FormRadarStub()
        {
            InitializeComponent();
            t = new Thread(connect);
            comboBoxCloudId.SelectedIndex = 1;
            comboBoxIntensity.SelectedIndex = 1;
            iPEndPointServer = new IPEndPoint(ipAdressServer, portNoServer);
            iPEndPointClient = new IPEndPoint(ipAdressClient, portNoClient);
            // typecasting ipendpoint to endpoint
            remote = (EndPoint)iPEndPointClient;
            socket.Bind(iPEndPointServer);

            //t.Start();//starting connect function thread
        }

        private void connect()
        {
            flag = false;
            try
            {
                currentLatitude = initialLat;

                currentLongitude = initialLong;
                DateTime time1 = DateTime.Now;
                while (i < 10)
                {
                    //DateTime time2 = DateTime.Now;
                    //TimeSpan ts = time2 - time1;
                    //double tsSec = ts.Seconds;
                    bearingRadian = bearing * Math.PI / 180;
                    if (bearing < heading)
                    {
                        if ((bearing + rateOfturn) < heading)
                            bearing = bearing + rateOfturn;
                        else
                            bearing = heading;
                    }
                    else if (bearing > heading)
                    {
                        if ((bearing - rateOfturn) > heading)
                            bearing = bearing - rateOfturn;
                        else
                            bearing = heading;
                    }
                    groundspeedMPSLat = Math.Cos(bearingRadian) * groundSpeed * 5 / 18;
                    groundspeedMPSLong = Math.Sin(bearingRadian) * groundSpeed * 5 / 18;
                    double latIncrement = groundspeedMPSLat/radius;
                    currentLatitude = currentLatitude + latIncrement;
                    double longIncrement = groundspeedMPSLong/(radius*Math.Cos(currentLatitude * Math.PI / 180));
                    currentLongitude = currentLongitude + longIncrement;
                    
                    if (InvokeRequired)
                    {
                        BeginInvoke(new Action(() =>
                        {
                            textBoxLat.Text = Convert.ToString(currentLatitude);
                            textBoxLong.Text = Convert.ToString(currentLongitude);
                            textBoxbearing.Text = Convert.ToString(bearing);
                            intensity = comboBoxIntensity.Text;
                            cloudId = comboBoxCloudId.Text;
                        }));
                    }
                    else
                    {
                        textBoxLat.Text = Convert.ToString(currentLatitude);
                        textBoxLong.Text = Convert.ToString(currentLongitude);
                        textBoxbearing.Text = Convert.ToString(bearing);
                        intensity = comboBoxIntensity.Text;
                        cloudId = comboBoxCloudId.Text;
                    }
                    dataSend = Convert.ToString(currentLatitude)+"$"+Convert.ToString(currentLongitude)+"$"+Convert.ToString(bearing)+"$"+Convert.ToString(groundSpeed)+"$";
                    point1 = textBoxLat1.Text + "," + textBoxLong1.Text + "," + textBoxHeight1.Text + ",";
                    point2 = textBoxLat2.Text + "," + textBoxLong2.Text + "," + textBoxHeight2.Text + ",";
                    point3 = textBoxLat3.Text + "," + textBoxLong3.Text + "," + textBoxHeight3.Text + ",";
                    point4 = textBoxLat4.Text + "," + textBoxLong4.Text + "," + textBoxHeight4.Text + ",";
                    point5 = textBoxLat5.Text + "," + textBoxLong5.Text + "," + textBoxHeight5.Text + ",";
                    point6 = textBoxLat6.Text + "," + textBoxLong6.Text + "," + textBoxHeight6.Text + ",";
                    point7 = textBoxLat7.Text + "," + textBoxLong7.Text + "," + textBoxHeight7.Text + ",";
                    point8 = textBoxLat8.Text + "," + textBoxLong8.Text + "," + textBoxHeight8.Text + ",";
                    point9 = textBoxLat9.Text + "," + textBoxLong9.Text + "," + textBoxHeight9.Text + ",";
                    point10 = textBoxLat10.Text + "," + textBoxLong10.Text + "," + textBoxHeight10.Text + ",";
                    final_cloud  =  cloudId + "@" + intensity+"*" + point1 + "@" + point2 + "@" +
                                    point3 + "@" + point4 + "@" + point5 + "@" + point6 + "@" +
                                    point7 + "@" + point8 + "@" + point9 + "@" + point10 + "@";
                    bufferSend = Encoding.ASCII.GetBytes(dataSend+"#"+final_cloud+"#");//converting string to byte datatype
                    socket.SendTo(bufferSend, remote);//send buffersend to remote
                    Thread.Sleep(1000);                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection not established\n"+ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //aborting connect function
            t.Abort();
            //closing socket
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
          
            try
            {
                initialLat = Convert.ToDouble(textBoxLat.Text);
                initialLong = Convert.ToDouble(textBoxLong.Text);
                groundSpeed = Convert.ToDouble(textBoxGroundSpeed.Text);
                bearing = Convert.ToDouble(textBoxbearing.Text);
                heading = Convert.ToDouble(textBoxHeading.Text);
                rateOfturn = Convert.ToDouble(textBoxRateOfTurn.Text);                
                labelLat.Text = "Initial Lat " + Convert.ToString(Convert.ToDouble(textBoxLat.Text));
                labelLong.Text = "Initial long "+ Convert.ToString(Convert.ToDouble(textBoxLong.Text));
                labelHeading.Text = "Initial bearing"+ Convert.ToString(Convert.ToDouble(textBoxbearing.Text));

            }
            catch
            {
                MessageBox.Show("Please enter correct values");
            }
            if(flag == true)
            t.Start();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
